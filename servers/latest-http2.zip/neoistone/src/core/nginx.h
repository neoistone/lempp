
/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) Nginx, Inc.
 */


#ifndef _NGINX_H_INCLUDED_
#define _NGINX_H_INCLUDED_


#define nginx_version      1020001
#define NEOISTONE          "Neoistone"
#define NEOISTONE_VERSION  "1.1.1"
#define NEOISTONE_VER       "Neoistone"

#define NGINX_VERSION      "1.1.1"
#define NGINX_VER          "Neoistone"
#define NEOISTONE_VER_BUILD  "Neoistone"

#ifdef NGX_BUILD
#define NGINX_VER_BUILD    "Neoistone"
#else
#define NGINX_VER_BUILD    "Neoistone"
#endif

#define NGINX_VAR          "Neoistone"
#define NGX_OLDPID_EXT     ".oldbin"


#endif /* _NGINX_H_INCLUDED_ */
