
/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) Nginx, Inc.
 */


#ifndef _NGINX_H_INCLUDED_
#define _NGINX_H_INCLUDED_


#define nginx_version      1020001
#define NEOISTONE          "Neoistone"
#define NEOISTONE_VERSION  "1.1.1"
#define NEOISTONE_VER      NEOISTONE "/" NEOISTONE_VERSION

#define NGINX_VERSION      NEOISTONE_VERSION
#define NGINX_VER          NEOISTONE_VER
#define NEOISTONE_VER_BUILD NEOISTONE " (" NEOISTONE_VERSION")"

#ifdef NGX_BUILD
#define NGINX_VER_BUILD    NEOISTONE " (" NGX_BUILD ")"
#else
#define NGINX_VER_BUILD    NGINX_VER
#endif

#define NGINX_VAR          NEOISTONE
#define NGX_OLDPID_EXT     ".oldbin"


#endif /* _NGINX_H_INCLUDED_ */
